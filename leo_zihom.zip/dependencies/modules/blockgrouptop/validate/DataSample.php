<?php
/**
 * 2007-2015 Leotheme
 *
 * NOTICE OF LICENSE
 *
 * Leo Prestashop Blockleoblogs for Prestashop 1.6.x
 *
 * DISCLAIMER
 *
 *  @author    leotheme <leotheme@gmail.com>
 *  @copyright 2007-2015 Leotheme
 *  @license   http://leotheme.com - prestashop template provider
 */

if (!defined('_CAN_LOAD_FILES_')) {
    exit;
}

class Datasample
{
    /**
     * Validate module
     */
}
